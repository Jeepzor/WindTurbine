#include "entity.h"

namespace wind {
	Entity::Entity() {
		xPos = 0;
		yPos = 0;
	}

}